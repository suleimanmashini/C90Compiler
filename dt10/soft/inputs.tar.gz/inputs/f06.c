int main()
{
    int x;
    x=5;
    x=x*x;
    return x; 
}

