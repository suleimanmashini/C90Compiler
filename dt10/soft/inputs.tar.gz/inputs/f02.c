int f()
{
    return 10;
}

int main()
{
    return f();
}

